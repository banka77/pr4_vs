﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Гебель4ПР
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
            Rectangle el = new Rectangle();
            el.Width = 150;
            el.Height = 150;
            el.VerticalAlignment = VerticalAlignment.Center;
            el.Fill = Brushes.White;
            el.Stroke = Brushes.Black;
            el.StrokeThickness = 15;
            grid1.Children.Add(el);


            Rectangle il = new Rectangle();
            il.Width = 200;
            il.Height = 60;
            il.Fill = Brushes.Black;
            il.Stroke = Brushes.Black;
            il.StrokeThickness = 3;
            grid1.Children.Add(il);
            il.Margin= new Thickness(150, -40, 100, 100);




            Rectangle al = new Rectangle();
            al.Width = 50;
            al.Height = 150;
            al.Fill = Brushes.Black;
            al.Stroke = Brushes.Black;
            al.StrokeThickness = 3;
            grid1.Children.Add(al);
            al.Margin = new Thickness(300, 100, 100, 100);


            Polygon pl1 = new Polygon();
            pl1.Stroke = Brushes.White;
            pl1.Fill = Brushes.White;
            System.Windows.Point point1 = new System.Windows.Point(382, 70);
            System.Windows.Point point2 = new System.Windows.Point(300, 80);
            System.Windows.Point point3 = new System.Windows.Point(300, 170);
            PointCollection myPointCollection = new PointCollection();
            myPointCollection.Add(point1);
            myPointCollection.Add(point2);
            myPointCollection.Add(point3);
            pl1.Points = myPointCollection;
            grid1.Children.Add (pl1);

            Polygon pl2 = new Polygon();
            pl2.Stroke = Brushes.White;
            pl2.Fill = Brushes.White;
            System.Windows.Point point4 = new System.Windows.Point(450, 350);
            System.Windows.Point point5 = new System.Windows.Point(600, 80);
            System.Windows.Point point6 = new System.Windows.Point(650, 170);
            PointCollection myPointCollection1 = new PointCollection();
            myPointCollection1.Add(point4);
            myPointCollection1.Add(point5);
            myPointCollection1.Add(point6);
            pl2.Points = myPointCollection1;
            grid1.Children.Add(pl2);

            Ellipse el1 = new Ellipse();
            el1.Stroke = Brushes.White;
            el1.Fill = Brushes.Black;
            el1.Width = 50;
            el1.Height = 20;
            el1.Margin = new Thickness(120, -60, 100, 100);
            grid1.Children.Add(el1);

            Line l1 = new Line();
            l1.Stroke = Brushes.Black;
            l1.Fill = Brushes.Black;
            l1.X1 = 445;
            l1.Y1 = 70;
            l1.X2 = 405;
            l1.Y2 = 120;
            l1.StrokeThickness = 4;
            grid1.Children.Add(l1);

            Line l2 = new Line();
            l2.Stroke = Brushes.Black;
            l2.Fill = Brushes.Black;
            l2.X1 = 375;
            l2.Y1 = 70;
            l2.X2 = 405;
            l2.Y2 = 130;
            l2.StrokeThickness = 4;
            grid1.Children.Add(l2);


            Ellipse el2 = new Ellipse();
            el2.Stroke = Brushes.Black;
            el2.Fill = Brushes.Black;
            el2.Width = 13;
            el2.Height = 13;
            el2.Margin = new Thickness(63,-178,100,100);
            grid1.Children.Add(el2);

            Ellipse el3 = new Ellipse();
            el3.Stroke = Brushes.Black;
            el3.Fill = Brushes.Black;
            el3.Width = 13;
            el3.Height = 13;
            el3.Margin = new Thickness(210, -178, 100, 100);
            grid1.Children.Add(el3);
        }
    }
}
