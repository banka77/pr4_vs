﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Гебель4ПР
{
    /// <summary>
    /// Логика взаимодействия для Window3.xaml
    /// </summary>
    public partial class Window3 : Window
    {
        public Window3()
        {
            InitializeComponent();
            Line l1 = new Line();
            l1.Stroke = Brushes.Black;
            l1.Fill = Brushes.Black;
            l1.StrokeThickness = 1;
            l1.X1 = 400;
            l1.Y1 = 50;
            l1.X2 = 400;
            l1.Y2 = 350;
            grid3.Children.Add(l1);

            Line l2 = new Line();
            l2.Stroke = Brushes.Black;
            l2.Fill = Brushes.Black;
            l2.StrokeThickness = 1;
            l2.X1 = 230;
            l2.Y1 = 200;
            l2.X2 = 570;
            l2.Y2 = 200;
            grid3.Children.Add(l2);

            Line l3 = new Line();
            l3.Stroke = Brushes.Black;
            l3.Fill = Brushes.Black;
            l3.StrokeThickness = 1;
            l3.X1 = 415;
            l3.Y1 = 205;
            l3.X2 = 415;
            l3.Y2 = 195;
            grid3.Children.Add(l3);

            Line l4 = new Line();
            l4.Stroke = Brushes.Black;
            l4.Fill = Brushes.Black;
            l4.StrokeThickness = 1;
            l4.X1 = 430;
            l4.Y1 = 205;
            l4.X2 = 430;
            l4.Y2 = 195;
            grid3.Children.Add(l4);

            Line l5 = new Line();
            l5.Stroke = Brushes.Black;
            l5.Fill = Brushes.Black;
            l5.StrokeThickness = 1;
            l5.X1 = 445;
            l5.Y1 = 205;
            l5.X2 = 445;
            l5.Y2 = 195;
            grid3.Children.Add(l5);

            Line l6 = new Line();
            l6.Stroke = Brushes.Black;
            l6.Fill = Brushes.Black;
            l6.StrokeThickness = 1;
            l6.X1 = 460;
            l6.Y1 = 205;
            l6.X2 = 460;
            l6.Y2 = 195;
            grid3.Children.Add(l6);

            Line l7 = new Line();
            l7.Stroke = Brushes.Black;
            l7.Fill = Brushes.Black;
            l7.StrokeThickness = 1;
            l7.X1 = 475;
            l7.Y1 = 205;
            l7.X2 = 475;
            l7.Y2 = 195;
            grid3.Children.Add(l7);

            Line l8 = new Line();
            l8.Stroke = Brushes.Black;
            l8.Fill = Brushes.Black;
            l8.StrokeThickness = 1;
            l8.X1 = 490;
            l8.Y1 = 205;
            l8.X2 = 490;
            l8.Y2 = 195;
            grid3.Children.Add(l8);

            Line l9 = new Line();
            l9.Stroke = Brushes.Black;
            l9.Fill = Brushes.Black;
            l9.StrokeThickness = 1;
            l9.X1 = 505;
            l9.Y1 = 205;
            l9.X2 = 505;
            l9.Y2 = 195;
            grid3.Children.Add(l9);

            Line l10 = new Line();
            l10.Stroke = Brushes.Black;
            l10.Fill = Brushes.Black;
            l10.StrokeThickness = 1;
            l10.X1 = 520;
            l10.Y1 = 205;
            l10.X2 = 520;
            l10.Y2 = 195;
            grid3.Children.Add(l10);

            Line l11 = new Line();
            l11.Stroke = Brushes.Black;
            l11.Fill = Brushes.Black;
            l11.StrokeThickness = 1;
            l11.X1 = 535;
            l11.Y1 = 205;
            l11.X2 = 535;
            l11.Y2 = 195;
            grid3.Children.Add(l11);

            Line l12 = new Line();
            l12.Stroke = Brushes.Black;
            l12.Fill = Brushes.Black;
            l12.StrokeThickness = 1;
            l12.X1 = 550;
            l12.Y1 = 205;
            l12.X2 = 550;
            l12.Y2 = 195;
            grid3.Children.Add(l12);

            Line ln1 = new Line();
            ln1.Stroke = Brushes.Black;
            ln1.Fill = Brushes.Black;
            ln1.StrokeThickness = 1;
            ln1.X1 = 385;
            ln1.Y1 = 205;
            ln1.X2 = 385;
            ln1.Y2 = 195;
            grid3.Children.Add(ln1);

            Line ln2 = new Line();
            ln2.Stroke = Brushes.Black;
            ln2.Fill = Brushes.Black;
            ln2.StrokeThickness = 1;
            ln2.X1 = 370;
            ln2.Y1 = 205;
            ln2.X2 = 370;
            ln2.Y2 = 195;
            grid3.Children.Add(ln2);

            Line ln11 = new Line();
            ln11.Stroke = Brushes.Black;
            ln11.Fill = Brushes.Black;
            ln11.StrokeThickness = 1;
            ln11.X1 = 355;
            ln11.Y1 = 205;
            ln11.X2 = 355;
            ln11.Y2 = 195;
            grid3.Children.Add(ln11);

            Line ln3 = new Line();
            ln3.Stroke = Brushes.Black;
            ln3.Fill = Brushes.Black;
            ln3.StrokeThickness = 1;
            ln3.X1 = 340;
            ln3.Y1 = 205;
            ln3.X2 = 340;
            ln3.Y2 = 195;
            grid3.Children.Add(ln3);

            Line ln4 = new Line();
            ln4.Stroke = Brushes.Black;
            ln4.Fill = Brushes.Black;
            ln4.StrokeThickness = 1;
            ln4.X1 = 325;
            ln4.Y1 = 205;
            ln4.X2 = 325;
            ln4.Y2 = 195;
            grid3.Children.Add(ln4);

            Line ln5 = new Line();
            ln5.Stroke = Brushes.Black;
            ln5.Fill = Brushes.Black;
            ln5.StrokeThickness = 1;
            ln5.X1 = 310;
            ln5.Y1 = 205;
            ln5.X2 = 310;
            ln5.Y2 = 195;
            grid3.Children.Add(ln5);

            Line ln6 = new Line();
            ln6.Stroke = Brushes.Black;
            ln6.Fill = Brushes.Black;
            ln6.StrokeThickness = 1;
            ln6.X1 = 295;
            ln6.Y1 = 205;
            ln6.X2 = 295;
            ln6.Y2 = 195;
            grid3.Children.Add(ln6);

            Line ln7 = new Line();
            ln7.Stroke = Brushes.Black;
            ln7.Fill = Brushes.Black;
            ln7.StrokeThickness = 1;
            ln7.X1 = 280;
            ln7.Y1 = 205;
            ln7.X2 = 280;
            ln7.Y2 = 195;
            grid3.Children.Add(ln7);

            Line ln8 = new Line();
            ln8.Stroke = Brushes.Black;
            ln8.Fill = Brushes.Black;
            ln8.StrokeThickness = 1;
            ln8.X1 = 265;
            ln8.Y1 = 205;
            ln8.X2 = 265;
            ln8.Y2 = 195;
            grid3.Children.Add(ln8);

            Line ln9 = new Line();
            ln9.Stroke = Brushes.Black;
            ln9.Fill = Brushes.Black;
            ln9.StrokeThickness = 1;
            ln9.X1 = 250;
            ln9.Y1 = 205;
            ln9.X2 = 250;
            ln9.Y2 = 195;
            grid3.Children.Add(ln9);

            Line ly1 = new Line();
            ly1.Stroke = Brushes.Black;
            ly1.Fill = Brushes.Black;
            ly1.StrokeThickness = 1;
            ly1.X1 = 405;
            ly1.Y1 = 215;
            ly1.X2 = 395;
            ly1.Y2 = 215;
            grid3.Children.Add(ly1);

            Line ly2 = new Line();
            ly2.Stroke = Brushes.Black;
            ly2.Fill = Brushes.Black;
            ly2.StrokeThickness = 1;
            ly2.X1 = 405;
            ly2.Y1 = 230;
            ly2.X2 = 395;
            ly2.Y2 = 230;
            grid3.Children.Add(ly2);

            Line ly3 = new Line();
            ly3.Stroke = Brushes.Black;
            ly3.Fill = Brushes.Black;
            ly3.StrokeThickness = 1;
            ly3.X1 = 405;
            ly3.Y1 = 245;
            ly3.X2 = 395;
            ly3.Y2 = 245;
            grid3.Children.Add(ly3);

            Line ly4 = new Line();
            ly4.Stroke = Brushes.Black;
            ly4.Fill = Brushes.Black;
            ly4.StrokeThickness = 1;
            ly4.X1 = 405;
            ly4.Y1 = 260;
            ly4.X2 = 395;
            ly4.Y2 = 260;
            grid3.Children.Add(ly4);

            Line ly5 = new Line();
            ly5.Stroke = Brushes.Black;
            ly5.Fill = Brushes.Black;
            ly5.StrokeThickness = 1;
            ly5.X1 = 405;
            ly5.Y1 = 275;
            ly5.X2 = 395;
            ly5.Y2 = 275;
            grid3.Children.Add(ly5);

            Line ly6 = new Line();
            ly6.Stroke = Brushes.Black;
            ly6.Fill = Brushes.Black;
            ly6.StrokeThickness = 1;
            ly6.X1 = 405;
            ly6.Y1 = 290;
            ly6.X2 = 395;
            ly6.Y2 = 290;
            grid3.Children.Add(ly6);

            Line ly7 = new Line();
            ly7.Stroke = Brushes.Black;
            ly7.Fill = Brushes.Black;
            ly7.StrokeThickness = 1;
            ly7.X1 = 405;
            ly7.Y1 = 305;
            ly7.X2 = 395;
            ly7.Y2 = 305;
            grid3.Children.Add(ly7);

            Line ly8 = new Line();
            ly8.Stroke = Brushes.Black;
            ly8.Fill = Brushes.Black;
            ly8.StrokeThickness = 1;
            ly8.X1 = 405;
            ly8.Y1 = 320;
            ly8.X2 = 395;
            ly8.Y2 = 320;
            grid3.Children.Add(ly8);

            Line ly9 = new Line();
            ly9.Stroke = Brushes.Black;
            ly9.Fill = Brushes.Black;
            ly9.StrokeThickness = 1;
            ly9.X1 = 405;
            ly9.Y1 = 335;
            ly9.X2 = 395;
            ly9.Y2 = 335;
            grid3.Children.Add(ly9);

            Line lyn1 = new Line();
            lyn1.Stroke = Brushes.Black;
            lyn1.Fill = Brushes.Black;
            lyn1.StrokeThickness = 1;
            lyn1.X1 = 405;
            lyn1.Y1 = 185;
            lyn1.X2 = 395;
            lyn1.Y2 = 185;
            grid3.Children.Add(lyn1);

            Line lyn2 = new Line();
            lyn2.Stroke = Brushes.Black;
            lyn2.Fill = Brushes.Black;
            lyn2.StrokeThickness = 1;
            lyn2.X1 = 405;
            lyn2.Y1 = 170;
            lyn2.X2 = 395;
            lyn2.Y2 = 170;
            grid3.Children.Add(lyn2);

            Line lyn3 = new Line();
            lyn3.Stroke = Brushes.Black;
            lyn3.Fill = Brushes.Black;
            lyn3.StrokeThickness = 1;
            lyn3.X1 = 405;
            lyn3.Y1 = 155;
            lyn3.X2 = 395;
            lyn3.Y2 = 155;
            grid3.Children.Add(lyn3);

            Line lyn4 = new Line();
            lyn4.Stroke = Brushes.Black;
            lyn4.Fill = Brushes.Black;
            lyn4.StrokeThickness = 1;
            lyn4.X1 = 405;
            lyn4.Y1 = 140;
            lyn4.X2 = 395;
            lyn4.Y2 = 140;
            grid3.Children.Add(lyn4);

            Line lyn5 = new Line();
            lyn5.Stroke = Brushes.Black;
            lyn5.Fill = Brushes.Black;
            lyn5.StrokeThickness = 1;
            lyn5.X1 = 405;
            lyn5.Y1 = 125;
            lyn5.X2 = 395;
            lyn5.Y2 = 125;
            grid3.Children.Add(lyn5);

            Line lyn6 = new Line();
            lyn6.Stroke = Brushes.Black;
            lyn6.Fill = Brushes.Black;
            lyn6.StrokeThickness = 1;
            lyn6.X1 = 405;
            lyn6.Y1 = 110;
            lyn6.X2 = 395;
            lyn6.Y2 = 110;
            grid3.Children.Add(lyn6);

            Line lyn7 = new Line();
            lyn7.Stroke = Brushes.Black;
            lyn7.Fill = Brushes.Black;
            lyn7.StrokeThickness = 1;
            lyn7.X1 = 405;
            lyn7.Y1 = 95;
            lyn7.X2 = 395;
            lyn7.Y2 = 95;
            grid3.Children.Add(lyn7);

            Line lyn8 = new Line();
            lyn8.Stroke = Brushes.Black;
            lyn8.Fill = Brushes.Black;
            lyn8.StrokeThickness = 1;
            lyn8.X1 = 405;
            lyn8.Y1 = 80;
            lyn8.X2 = 395;
            lyn8.Y2 = 80;
            grid3.Children.Add(lyn8);

            Line lyn9 = new Line();
            lyn9.Stroke = Brushes.Black;
            lyn9.Fill = Brushes.Black;
            lyn9.StrokeThickness = 1;
            lyn9.X1 = 405;
            lyn9.Y1 = 65;
            lyn9.X2 = 395;
            lyn9.Y2 = 65;
            grid3.Children.Add(lyn9);

            Polyline vertArr = new Polyline();
            vertArr.Points = new PointCollection();
            vertArr.Points.Add(new Point(395, 55));
            vertArr.Points.Add(new Point(400, 50));
            vertArr.Points.Add(new Point(405, 55));
            vertArr.Stroke = Brushes.Black;
            grid3.Children.Add(vertArr);

            Polyline horArr = new Polyline();
            horArr.Points = new PointCollection();
            horArr.Points.Add(new Point(560, 205));
            horArr.Points.Add(new Point(570, 200));
            horArr.Points.Add(new Point(560, 195));
            horArr.Stroke = Brushes.Black;
            grid3.Children.Add(horArr);

            TextBlock t1 = new TextBlock();
            t1.Text = "X";
            t1.FontSize = 13;
            t1.Margin = new Thickness(580, 190, 100, 100);
            grid3.Children.Add(t1);

            TextBlock t2 = new TextBlock();
            t2.Text = "Y";
            t2.FontSize = 13;
            t2.Margin = new Thickness(410, 40, 100, 100);
            grid3.Children.Add(t2);


            Point sp = new Point(345, 290); // Начальная точка
            Point p1 = new Point(380, -70); // Первая контрольная точка
            Point p2 = new Point(385, 490); // Вторая контрольная точка
            Point pe = new Point(430, 100); // Конечная точка

            var bs = new BezierSegment(p1, p2, pe, true);
            var pf = new PathFigure(sp, new[] { bs }, false);

            // Создаем геометрию пути и добавляем её в графику
            var pg = new PathGeometry(new[] { pf });
            var path = new Path
            {
                Data = pg,
                Stroke = Brushes.Blue,
                StrokeThickness = 2 
            };
            grid3.Children.Add(path);
        }
    }
}
