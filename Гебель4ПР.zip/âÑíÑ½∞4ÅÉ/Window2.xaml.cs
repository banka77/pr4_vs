﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Гебель4ПР
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public Window2()
        {
            InitializeComponent();
            Polygon l1 = new Polygon();
            l1.Stroke = Brushes.Black;
            l1.Fill = Brushes.White;
            l1.StrokeThickness = 2;
            System.Windows.Point point1 = new System.Windows.Point(382, 70);
            System.Windows.Point point2 = new System.Windows.Point(250, 300);
            System.Windows.Point point3 = new System.Windows.Point(510, 300);
            PointCollection myPointCollection = new PointCollection();
            myPointCollection.Add(point1);
            myPointCollection.Add(point2);
            myPointCollection.Add(point3);
            l1.Points = myPointCollection;
            grid2.Children.Add(l1);

            Polygon p2 = new Polygon();
            p2.Stroke = Brushes.Black;
            p2.Fill = Brushes.Pink;
            p2.StrokeThickness = 2;
            System.Windows.Point point12 = new System.Windows.Point(380, 190);
            System.Windows.Point point23 = new System.Windows.Point(250, 300);
            System.Windows.Point point34 = new System.Windows.Point(510, 300);
            p2.StrokeDashArray = new DoubleCollection { 5, 3 };
            PointCollection myPointCollection2 = new PointCollection();
            myPointCollection2.Add(point12);
            myPointCollection2.Add(point23);
            myPointCollection2.Add(point34);
            p2.Points = myPointCollection2;
            grid2.Children.Add(p2);

            Line ln1 = new Line();
            ln1.Stroke = Brushes.Black;
            ln1.Fill = Brushes.Black;
            ln1.X1 = 382;
            ln1.Y1 = 70;
            ln1.X2 = 382;
            ln1.Y2 = 280;
            ln1.StrokeDashArray = new DoubleCollection { 5, 3 };
            grid2.Children.Add(ln1);

            Line ln2 = new Line();
            ln2.Stroke = Brushes.Black;
            ln2.Fill = Brushes.Black;
            ln2.X1 = 510;
            ln2.Y1 = 300;
            ln2.X2 = 380;
            ln2.Y2 = 250;
            ln2.StrokeDashArray = new DoubleCollection {5, 3};
            grid2.Children.Add(ln2);

            Line ln3 = new Line();
            ln3.Stroke = Brushes.Black;
            ln3.Fill = Brushes.Black;
            ln3.X1 = 250;
            ln3.Y1 = 300;
            ln3.X2 = 380;
            ln3.Y2 = 252;
            ln3.StrokeDashArray = new DoubleCollection {5, 3};
            grid2.Children.Add(ln3);



            Ellipse el3 = new Ellipse();
            el3.Stroke = Brushes.Black;
            el3.Fill = Brushes.Black;
            el3.Width = 8;
            el3.Height = 8;
            el3.Margin = new Thickness(80, 250, 100, 100);
            grid2.Children.Add(el3);

            TextBlock t1 = new TextBlock();
            t1.Text = "A";
            t1.FontSize = 20;
            t1.Margin = new Thickness(390, 50, 100, 100);
            grid2.Children.Add(t1);

            TextBlock t2 = new TextBlock();
            t2.Text = "B";
            t2.FontSize = 20;
            t2.Margin = new Thickness(230, 280, 100, 100);
            grid2.Children.Add(t2);

            TextBlock t3 = new TextBlock();
            t3.Text = "C";
            t3.FontSize = 20;
            t3.Margin = new Thickness(520, 280, 100, 100);
            grid2.Children.Add(t3);

            TextBlock t4 = new TextBlock();
            t4.Text = "D";
            t4.FontSize = 20;
            t4.Margin = new Thickness(385, 225, 100, 100);
            grid2.Children.Add(t4);

            Line l10 = new Line();
            l10.Stroke = Brushes.Black;
            l10.Fill = Brushes.Black;
            l10.StrokeThickness = 2;
            l10.X1 = 510;
            l10.Y1 = 300;
            l10.X2 = 250;
            l10.Y2 = 300;
            grid2.Children.Add(l10);
        }
    }
}
